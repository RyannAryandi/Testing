# Coded by @ferdysr
`Terimakasih sudah membeli 🤗`

### Tutorial Cara Pemasangan :
```js
1. Pastikan sudah memiliki application yang dibuat di https://discord.com/developers/applications
2. Pastikan sudah meng-upload gambar yang akan ditampilkan pada custom activity (Di Discord Developer)
3. Pastikan anda sudah memiliki token akun yang akan dipasang custom activity

5. Pergi ke file yang bernama CONFIG.JSON
6. Isikan semua yang diperlukan (ID Application yang dibuat di Discord Developer, Text, dan Nama gambar yang sudah diupload di Discord Developer)
7. Di replit, pergi ke tools lalu Secrets, klik "New Secret" dan isikan key "TOKEN" (tanpa tanda petik 2) dan value diisi dengan token akun yang akan dipasang custom activity lalu klik save

Setelah itu anda bisa mengaktifkan custom activity dengan menekan tombol hijau bertuliskan RUN.
```

## Hubungi Saya :
<p align="center">
  <a href="https://discord.gg/xEUQSqNC6V">
    <button">Discord</button>
  </a>
  
  <img src="https://i.postimg.cc/vBm3rDg7/Ferdy-Shop.jpg" height="240" width="240" alt="FerdySR">
</p>