const chalk = require('chalk');
const rpc = require("discordrpcgenerator");
const config = require(".././config.json")

module.exports = async(client) => {
  const small = await rpc.getRpcImage(config.applicationid, config.nama_gambar)
  .then(large => {
    let presence = new rpc.Rpc()
    .setName(config.text)
    .setUrl('https://www.twitch.tv/ferdyry')
    .setType('PLAYING')
    .setApplicationId(config.applicationid)
    .setAssetsLargeImage(large.id)
    .setAssetsLargeText(large.name)
    client.user.setPresence(presence.toDiscord()).catch(console.error);
  })
  console.log(chalk.hex("#00ff00")("RPC Aktif!"))
 }